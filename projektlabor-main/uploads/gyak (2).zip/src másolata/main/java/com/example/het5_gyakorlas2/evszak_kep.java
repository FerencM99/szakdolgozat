package com.example.het5_gyakorlas2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.Toast;

public class evszak_kep extends AppCompatActivity {
    private final int ITEMID_SHOWMESSAGE=1;
    Switch s1;
    RadioGroup rg;
    RadioButton rbo, rbf, rbh;
    EditText fo;
    String hely;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evszak_kep);
        final LinearLayout lm= findViewById(R.id.kepesl);
        Animation pushAnim = AnimationUtils.loadAnimation(this,R.anim.animacio);
        lm.startAnimation(pushAnim);

        s1 = findViewById(R.id.switch1);
        s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked())
                {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse("http://www.nyaralas.hu"));
                    startActivity(i);
                }
            }
        });

        rbo = findViewById(R.id.rbo);
        rbh = findViewById(R.id.rbh);
        rbf = findViewById(R.id.rbf);
        fo = findViewById(R.id.fo);
        Button osszegzes = findViewById(R.id.button);
        osszegzes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer szemely = Integer.parseInt(fo.getText().toString());
                Log.d("ittjar",String.valueOf(szemely));
                Integer ar = 0;
                if (rbf.isChecked()) {ar = 69999; hely="Franciaország";}
                if (rbh.isChecked()) {ar = 49999; hely="Horvátország";}
                if (rbo.isChecked()) {ar = 59999; hely="Olaszország";}

                ar *= szemely;

                //Toast.makeText(getApplicationContext(), String.valueOf(ar), Toast.LENGTH_LONG).show();

                Intent i = new Intent(getApplicationContext(), utazas.class);
                i.putExtra("fo",szemely);
                i.putExtra("ar",ar);
                i.putExtra("hova",hely);
                startActivity(i);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        s1.setChecked(false);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu){
        menu.clear();
        menu.add(Menu.NONE, ITEMID_SHOWMESSAGE,0,"Show popup").setAlphabeticShortcut('c');
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case ITEMID_SHOWMESSAGE:
                Toast.makeText(this,"Hello!",Toast.LENGTH_LONG).show();
                break;
        }
        return true;
    }


}

