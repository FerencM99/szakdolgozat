package com.example.het5_gyakorlas2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView eredmeny;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eredmeny = findViewById(R.id.eredmeny);

    }

    public void PopUpShow(View v){
        LayoutInflater l =(LayoutInflater)getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = l.inflate(R.layout.popup,null);
        final PopupWindow pop=new PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        Button btnDismiss = (Button) popupView.findViewById(R.id.btnPopUpOK);
        btnDismiss.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                pop.dismiss();uzi();
            }
        });
        pop.showAsDropDown(eredmeny,0,0);

    }

    public void evszak_kep_katt(View v){
        Intent i=new Intent(this,evszak_kep.class);
        startActivity(i);
    }
    public void evszak_tulajdonsag_katt(View v){
        Intent i=new Intent(this,evszak_jellemzo.class);
        startActivity(i);
    }
    public void szamolas_katt(View v){
        Intent i=new Intent(this,szamolas.class);
        startActivityForResult(i,1);
    }

    public void kepre_katt(View v){
        Intent i=new Intent(this,bevezeto.class);
        startActivity(i);
    }

    public void uzi(){
        Toast.makeText(this,"A mai nap különlegesen szép lesz! :-)",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==1)
        {
            eredmeny.setText("Utolsó érték: "+data.getStringExtra("ertek"));
        }
    }
}
