package com.example.het5_gyakorlas2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class szamolas extends AppCompatActivity {
    int eredmeny;
    EditText szam;
    TextView proba;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_szamolas);
        szam = findViewById(R.id.szammezo);
        proba = findViewById(R.id.proba);
        eredmeny=0;
    }

    public void showAlertMessage(final String aMessage){
        AlertDialog.Builder alertbox=new AlertDialog.Builder(this);
        alertbox.setMessage(aMessage);
        alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                eredmeny = eredmeny + Integer.parseInt(szam.getText().toString());
                szam.setText("");
                proba.setText(String.valueOf(eredmeny));
            }
        });
        alertbox.show();
    }

    public void plusz(View v){
       /* eredmeny = eredmeny + Integer.parseInt(szam.getText().toString());
        szam.setText("");
        proba.setText(String.valueOf(eredmeny));
        */
        showAlertMessage("Az összeadás megtörtént!");
    }

    public void egyenloseg(View v) {
        eredmeny = eredmeny+Integer.parseInt(szam.getText().toString());
        String kuld=String.valueOf(eredmeny);
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("ertek", kuld);
        setResult(1, intent);
        finish();
    }
}
