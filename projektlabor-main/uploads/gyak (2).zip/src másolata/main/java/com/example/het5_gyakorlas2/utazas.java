package com.example.het5_gyakorlas2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class utazas extends AppCompatActivity {

    TextView cel, szemelyek, ar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utazas);
        cel = findViewById(R.id.cel);
        szemelyek = findViewById(R.id.szemelyek);
        ar = findViewById(R.id.ar);
        Bundle b = getIntent().getExtras();
        if (b != null){
            cel.setText(b.getString("hova"));
            szemelyek.setText(Integer.toString(b.getInt("fo")));
            ar.setText(Integer.toString(b.getInt("ar")));
        }
    }
}