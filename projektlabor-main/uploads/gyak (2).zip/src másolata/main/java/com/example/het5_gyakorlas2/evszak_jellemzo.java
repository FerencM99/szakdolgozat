package com.example.het5_gyakorlas2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class evszak_jellemzo extends AppCompatActivity {
    ListView listamezo;
    ArrayAdapter<String> adapter;
    EditText e;
    Button uj;
    Button torol;
    String kivalasztott;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evszak_jellemzo);
        e = findViewById(R.id.tulajdonsag);
        uj = findViewById(R.id.uj);
        torol = findViewById(R.id.torles);
        listamezo = (ListView)findViewById(R.id.listamezo);
        final ArrayList<String> sztringlista = new ArrayList<String>();
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,sztringlista);
        listamezo.setAdapter(adapter);
        adapter.add("sok napsütés");
        adapter.add("jó idő");
        adapter.add("strandolás");
        listamezo.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                kivalasztott =adapter.getItem(i);
                e.setText(kivalasztott);
            }
        });
    }

    public void felvesz(View v){
        adapter.add(e.getText().toString());
        e.setText("");
    }

    public void torles(View v){
        adapter.remove(kivalasztott);
        e.setText("");
    }
}
