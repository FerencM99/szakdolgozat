package com.example.adattarolas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    
    EditText nev, kor;
    TextView inditasok;
    int db;
    SharedPreferences sp;
    String datum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nev = findViewById(R.id.nev);
        kor = findViewById(R.id.kor);
        inditasok = findViewById(R.id.inditasok);
        sp = getSharedPreferences("adatok",MODE_PRIVATE);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
                Locale.getDefault());
        datum = sdf.format(new Date());
    }

    @Override
    protected void onResume() {
        super.onResume();
        //adatok betöltése
        String neve = sp.getString("nev_kulcs","");
        String kora = sp.getString("kor_kulcs","");
        db = sp.getInt("inditas_kulcs",1);
        Boolean elso = sp.getBoolean("elso_kulcs",true);
        if (elso){//1. indítás
            Toast.makeText(this, "Első indítás! \n" +
                    "Kérlek add meg a neved és a korod!", Toast.LENGTH_SHORT).show();
        }
        else {//nem 1. indítás
            Toast.makeText(this, "Szia "+neve+"!", Toast.LENGTH_SHORT).show();
            nev.setText(neve);
            kor.setText(kora);
            nev.setEnabled(false);
            kor.setEnabled(false);
            inditasok.setText(db + "x");
        }

        //InternalStorage...
        FileOutputStream foutput = null;
        try {
            foutput = openFileOutput("inditasszam",MODE_APPEND);
            datum = datum +"\n";
            foutput.write(datum.getBytes());
            foutput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        db++;
        //adatmentés
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("nev_kulcs", nev.getText().toString());
        editor.putString("kor_kulcs", kor.getText().toString());
        editor.putInt("inditas_kulcs",db);
        editor.putBoolean("elso_kulcs",false);
        editor.commit();

        //ExternalStorage
        File file=getExternalFilesDir(null);
        String filen = file.getAbsolutePath()+"/inditassz_es.txt";
        try {
            FileOutputStream fileo = new FileOutputStream(filen);
            fileo.write(Integer.toString(db).getBytes());
            fileo.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}