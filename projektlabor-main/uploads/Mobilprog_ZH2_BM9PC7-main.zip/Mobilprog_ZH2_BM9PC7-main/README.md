# Mobilprog_ZH2_BM9PC7
Második mobilprog zh hétfői csoport megoldás

<h1>Feladat leírása:</h1>


![feladat_leiras_kep](feladat_leiras.jpg)
